package com.example.structdata;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StructdataApplicationTests {

    @Test
    void contextLoads() {
    }

}

package com.example.structdata;

import com.example.structdata.utils.RamPagerHelper;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

@SpringBootApplication
public class StructdataApplication implements CommandLineRunner {

    public static void main(String[] args) {
        SpringApplication.run(StructdataApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        System.out.println("程序启动...");

//        LocalDateTime now = LocalDateTime.now();
//
//        LocalDate localDate = now.toLocalDate();
//
//        LocalTime localTime = now.toLocalTime();
//
//        String strDate = localDate.toString();
//        String strTime = localTime.toString();
//
//        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
//        LocalDateTime localDateNew = LocalDateTime.parse("2019-12-07 07:43:53", formatter);
//
//        LongAdder longAdder = new LongAdder();
//
//        String str = "";

//        List<String> list = Arrays.asList("yellow", "red", "green", "blue");
//        //注意该方法是取反，并不是逆序排序
//        Collections.reverse(list);
////        Collections.sort(list);
////        Collections.reverse(list);
//        Collections.sort(list);
//        int green = Collections.binarySearch(list, "blue");
//        System.out.println(String.format("二分查找:%s", green));
//        String str = String.format("%04d", youNumber);
//        List<String> lstImgUrl = new ArrayList<>();
//        for (int i = 0; i < 5; i++) {
//            String str = String.format("str_%04d", i);
//            lstImgUrl.add(str);
//        }
//
//        List<List<String>> lists = ArraysUtils.divideEqually(lstImgUrl, 5);
//
//
//        String myStr = "Good morning.Have a good class.Have a good class.Have fun!";
//        String[] words = myStr.split("[\\s+\\p{P}]");
////        TreeMap<String, Integer> treeMap = new TreeMap<>((s, anotherString) -> s.compareTo(anotherString));
//        TreeMap<String, Integer> treeMap = new TreeMap<>();
//        for (String item : words) {
//            if (StringUtils.isNotBlank(item)) {
//                if (!treeMap.containsKey(item)) {
//                    treeMap.put(item, 1);
//                } else {
//                    Integer integer = treeMap.get(item);
//                    treeMap.put(item, ++integer);
//                }
//            }
//        }
//
//        treeMap.forEach((k, v) -> {
//            System.out.println(String.format("k=%s,v=%s", k, v));
//        });
//
//        String text = "";


        List<Integer> list = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8);
        System.out.println("原始数据是：" + list);

        int pageSize = 2;
        System.out.println("每页大小是：" + pageSize);

        RamPagerHelper<Integer> pager = new RamPagerHelper<>(list, pageSize);
        System.out.println("总页数是: " + pager.getPageCount());

        System.out.println("<- - - - - - - - - - - - - ->");

        // 无需感知页码情况下使用
        Iterator<List<Integer>> iterator = pager.iterator();
        while (iterator.hasNext()) {
            List<Integer> next = iterator.next();
            System.out.println("next: " + next);
        }

        System.out.println("<- - - - - - - - - - - - - ->");
        // 需要指定页码情况使用，页码从第一页开始，且小于等于总页数！
        for (int i = 1; i <= pager.getPageCount(); i++) {
            List<Integer> page = pager.page(i);
            System.out.println("第 " + i + " 页数据是:" + page);
        }
    }
}
